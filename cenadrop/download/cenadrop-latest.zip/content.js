// content.js — CenaDrop Flow v7.0

const VERSION = 'v7.0';
console.log(`[CenaDrop Flow ${VERSION}] Iniciado em:`, location.href);

let _running = false;
let _stopRequested = false;

// ── Mensagens ─────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'processJson') {
    console.log(`[Flow ${VERSION}] Recebido: ${msg.scenes.length} cenas`);
    runAutomation(msg.scenes, msg.waitTime || 100);
  }
  if (msg.action === 'stop') {
    _stopRequested = true;
    _running = false;
    safeStorage({ flow_stop: true, flow_running: false });
    sendStatus('Parado pelo usuário.', -1);
  }
  // Limpa qualquer estado travado de uma execução anterior
  if (msg.action === 'forceReset') {
    _stopRequested = true;
    _running = false;
  }
  sendResponse({ ok: true });
  return true;
});

function sendStatus(status, index, extra = {}) {
  safeStorage({ flow_last_status: status, flow_running: _running });
  try { chrome.runtime.sendMessage({ action: 'updateStatus', status, fileIndex: index, ...extra }).catch(() => {}); } catch(e) {}
}

function setNextDownloadName(filename) {
  try { chrome.runtime.sendMessage({ action: 'setNextDownloadName', filename }).catch(() => {}); } catch(e) {}
}

function safeStorage(obj) {
  try { return chrome.storage.local.set(obj); } catch(e) { return Promise.resolve(); }
}

async function safeGet(key) {
  try { const r = await chrome.storage.local.get([key]); return r[key]; } catch(e) { return null; }
}

// ── Utilitários ───────────────────────────────────────────────────────────────
function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

async function waitForElement(fn, tries = 15, interval = 400) {
  for (let i = 0; i < tries; i++) {
    const el = fn();
    if (el) return el;
    await delay(interval);
  }
  return null;
}

function getEditUrlSet() {
  const urls = new Set();
  document.querySelectorAll('a[href*="/edit/"]').forEach(a => { if (a.href) urls.add(a.href); });
  return urls;
}

function getNewEditUrl(before) {
  for (const url of getEditUrlSet()) {
    if (!before.has(url)) return url;
  }
  return null;
}

// ── Captura o /edit/ID após enviar um prompt ──────────────────────────────────
async function captureEditId(item, editsBefore) {
  await delay(3000);
  let newUrl = getNewEditUrl(editsBefore);
  for (let retry = 1; retry <= 4 && !newUrl; retry++) {
    console.log(`[Flow] Cena ${item.scene_number}: ID não encontrado, tentativa ${retry}/4 em 2s...`);
    await delay(2000);
    newUrl = getNewEditUrl(editsBefore);
  }
  if (newUrl) {
    item.editUrl = newUrl;
    item.videoId = newUrl.split('/edit/')[1]?.split('?')[0] || null;
    console.log(`[Flow] Cena ${item.scene_number} → ID: ${item.videoId?.substring(0, 8)}`);
  } else {
    console.warn(`[Flow] Cena ${item.scene_number}: ID não capturado`);
  }
}

// ── Aguarda o popup sinalizar que o usuário clicou em Baixar ──────────────────
async function waitForDownloadSignal() {
  await safeStorage({ flow_download_ready: false });
  while (true) {
    if (await safeGet('flow_stop') || _stopRequested) return false;
    if (await safeGet('flow_download_ready')) break;
    await delay(500);
  }
  await safeStorage({ flow_download_ready: false });
  return true;
}

// ── AUTOMAÇÃO PRINCIPAL ───────────────────────────────────────────────────────
async function runAutomation(scenes) {
  if (_running) { sendStatus('Já existe um processo rodando!', -1); return; }
  if (!location.href.includes('/tools/flow/project/') || location.href.includes('/edit/')) {
    sendStatus('⚠️ Abra a lista do projeto no Flow antes de iniciar!', -1);
    return;
  }

  _running = true;
  _stopRequested = false;
  safeStorage({ flow_stop: false, flow_running: true });

  const items = scenes
    .map((s, i) => ({
      prompt:       s.prompt || s.text || '',
      scene_number: s.scene_number || (i + 1),
      index:        i,
      filename:     String(s.scene_number || i + 1).padStart(3, '0') + '_Flow_Video',
      editUrl:      null,
      videoId:      null,
    }))
    .filter(s => s.prompt.trim().length > 0);

  const total = items.length;
  sendStatus(`Iniciando ${total} cenas...`, 0);

  // ════════════════════════════════════════════════════════════════════════════
  // FASE 1 — Envia prompts e captura /edit/ID de cada um
  // ════════════════════════════════════════════════════════════════════════════
  let sentCount = 0;

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    if (await safeGet('flow_stop') || _stopRequested) break;

    sendStatus(`Enviando ${i + 1}/${total}: cena ${item.scene_number}`, item.index);

    const editsBefore = getEditUrlSet();
    const sent = await sendPrompt(item.prompt);

    if (!sent) {
      sendStatus(`⚠️ Cena ${item.scene_number} falhou no envio`, item.index);
      continue;
    }

    sentCount++;
    sendStatus(`✅ Enviado ${sentCount}/${total} — cena ${item.scene_number}`, item.index, { sent: true });
    await captureEditId(item, editsBefore);
  }

  // ════════════════════════════════════════════════════════════════════════════
  // Aguarda o clique em "Baixar" no popup
  // ════════════════════════════════════════════════════════════════════════════
  sendStatus(`✅ ${sentCount}/${total} enviados — clique em Baixar quando os vídeos estiverem prontos!`, -1, { allSent: true });

  const shouldDownload = await waitForDownloadSignal();
  if (!shouldDownload) {
    safeStorage({ flow_running: false });
    _running = false;
    return;
  }

  sendStatus('⬇️ Iniciando downloads...', -1);

  // ════════════════════════════════════════════════════════════════════════════
  // FASE 2 — Baixa cada vídeo pelo ID do card; até 2 rounds de reenvio
  // ════════════════════════════════════════════════════════════════════════════
  let toDownload    = items.filter(i => i.videoId);
  let allDownloaded = 0;
  let failedItems   = [];
  const MAX_RETRY_ROUNDS = 2;

  for (let round = 0; round <= MAX_RETRY_ROUNDS; round++) {
    if (toDownload.length === 0) break;

    const roundLabel = round === 0 ? '' : ` [Reenvio ${round}/${MAX_RETRY_ROUNDS}]`;
    sendStatus(`${roundLabel}Baixando ${toDownload.length} vídeo(s)...`.trim(), -1);
    failedItems = [];

    for (let i = 0; i < toDownload.length; i++) {
      const item = toDownload[i];
      if (await safeGet('flow_stop') || _stopRequested) break;

      sendStatus(`${roundLabel}[${i + 1}/${toDownload.length}] Cena ${item.scene_number}...`.trim(), item.index);

      const ok = await downloadFromQueue(item);
      if (ok) {
        allDownloaded++;
        sendStatus(`✅ ${item.filename}.mp4 (${allDownloaded} baixados)`, item.index, { downloaded: true });
      } else {
        failedItems.push(item);
        sendStatus(`⚠️ Cena ${item.scene_number} falhou`, item.index);
      }

      if (i < toDownload.length - 1) await delay(2000);
    }

    if (await safeGet('flow_stop') || _stopRequested) break;
    if (failedItems.length === 0) break;
    if (round >= MAX_RETRY_ROUNDS) break;

    // Reenvia prompts das cenas que falharam e captura novos IDs
    const names = failedItems.map(it => `#${it.scene_number}`).join(', ');
    sendStatus(`🔄 ${failedItems.length} cena(s) falharam: ${names}. Reenviando...`, -1);
    await delay(2000);

    const reItems = [];
    for (let i = 0; i < failedItems.length; i++) {
      const item = failedItems[i];
      if (await safeGet('flow_stop') || _stopRequested) break;

      sendStatus(`🔄 Reenviando cena ${item.scene_number} (${i + 1}/${failedItems.length})...`, item.index);

      const editsBefore = getEditUrlSet();
      const sent = await sendPrompt(item.prompt);

      if (!sent) {
        sendStatus(`⚠️ Reenvio da cena ${item.scene_number} falhou`, item.index);
        reItems.push(item); // mantém sem novo ID para tentar baixar de qualquer forma
        continue;
      }

      sendStatus(`✅ Cena ${item.scene_number} reenviada`, item.index, { sent: true });
      await captureEditId(item, editsBefore);
      item.filename = String(item.scene_number).padStart(3, '0') + '_Flow_Video';
      reItems.push(item);
    }

    const reWithId = reItems.filter(it => it.videoId);
    if (reWithId.length === 0) break;

    sendStatus(`✅ Reenvio ${round + 1} concluído — ${reWithId.length} pronto(s). Clique em Baixar!`, -1, { allSent: true });

    const shouldContinue = await waitForDownloadSignal();
    if (!shouldContinue) break;

    sendStatus('⬇️ Iniciando downloads...', -1);
    toDownload = reWithId;
  }

  // ── Encerramento ──────────────────────────────────────────────────────────
  safeStorage({ flow_running: false });

  if (failedItems.length === 0) {
    sendStatus(`🎉 Concluído! ${allDownloaded} vídeo(s) baixados.`, -1, { allDone: true });
  } else {
    const failedNames = failedItems.map(it => `#${it.scene_number}`).join(', ');
    sendStatus(
      `✅ ${allDownloaded} baixados. ⚠️ Não baixados após reenvios: ${failedNames}`,
      -1,
      { allDone: true, failedScenes: failedNames }
    );
  }

  _running = false;
}

// ─── BAIXA UM VÍDEO NA PÁGINA DE FILA ────────────────────────────────────────
async function downloadFromQueue(item) {
  try {
    if (location.href.includes('/edit/')) {
      history.back();
      await delay(2000);
    }

    window.scrollTo({ top: 0, behavior: 'instant' });
    await delay(500);

    const card = findCardById(item.videoId);
    if (!card) {
      console.warn(`[Flow] Card não encontrado para ID ${item.videoId?.substring(0, 8)}`);
      window.scrollTo({ top: 0, behavior: 'instant' });
      await delay(800);
      const card2 = findCardById(item.videoId);
      if (!card2) return false;
      return await clickMoreVertAndDownload(card2, item.filename);
    }

    return await clickMoreVertAndDownload(card, item.filename);
  } catch(e) {
    console.error('[Flow] Erro em downloadFromQueue:', e.message);
    return false;
  }
}

// ─── Encontra o card que contém o videoId no link href ───────────────────────
function findCardById(videoId) {
  if (!videoId) return null;

  const link = document.querySelector(`a[href*="/edit/${videoId}"]`);
  if (!link) {
    console.warn(`[Flow] Link /edit/${videoId?.substring(0, 8)} não encontrado na página`);
    return null;
  }

  let el = link.parentElement;
  for (let d = 0; d < 10; d++) {
    if (!el || el === document.body) break;
    const r = el.getBoundingClientRect();
    if (r.width >= 200 && r.height >= 100) {
      console.log(`[Flow] Card encontrado para ${videoId?.substring(0, 8)}: ${Math.round(r.width)}x${Math.round(r.height)}`);
      return el;
    }
    el = el.parentElement;
  }
  return null;
}

// ─── Encontra o botão more_vert dentro ou mais próximo do card ───────────────
function findMoreVertInCard(card) {
  const inCard = Array.from(card.querySelectorAll('button')).find(b =>
    b.querySelector('i')?.textContent?.trim() === 'more_vert'
  );
  if (inCard) return inCard;

  const allMV = Array.from(document.querySelectorAll('button')).filter(b =>
    b.querySelector('i')?.textContent?.trim() === 'more_vert'
  );
  if (allMV.length === 0) return null;

  const cardRect = card.getBoundingClientRect();
  return allMV.reduce((closest, b) => {
    const bRect = b.getBoundingClientRect();
    const dist  = Math.abs(bRect.left - cardRect.left) + Math.abs(bRect.top - cardRect.top);
    if (!closest) return b;
    const cRect    = closest.getBoundingClientRect();
    const closestDist = Math.abs(cRect.left - cardRect.left) + Math.abs(cRect.top - cardRect.top);
    return dist < closestDist ? b : closest;
  }, null);
}

// ─── Faz hover no card e clica no more_vert → Baixar → 720p ──────────────────
async function clickMoreVertAndDownload(card, filename) {
  let baixarNotFoundCount = 0;
  const MAX_BAIXAR_FAILS = 2;

  for (let attempt = 1; attempt <= 8; attempt++) {
    try {
      document.body.click();
      await delay(400);

      card.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await delay(800);

      const freshRect = card.getBoundingClientRect();
      const cx = freshRect.left + freshRect.width  / 2;
      const cy = freshRect.top  + freshRect.height / 2;

      card.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true, clientX: cx, clientY: cy }));
      card.dispatchEvent(new MouseEvent('mouseover',  { bubbles: true, clientX: cx, clientY: cy }));
      card.dispatchEvent(new MouseEvent('mousemove',  { bubbles: true, clientX: cx, clientY: cy }));
      await delay(700);

      const moreVertBtn = findMoreVertInCard(card);
      if (!moreVertBtn) {
        console.warn(`[Flow] Tentativa ${attempt}: more_vert não encontrado`);
        continue;
      }

      const br   = moreVertBtn.getBoundingClientRect();
      const bOpts = {
        bubbles: true, cancelable: true,
        clientX: br.left + br.width  / 2,
        clientY: br.top  + br.height / 2,
      };

      moreVertBtn.dispatchEvent(new MouseEvent('mouseenter', bOpts));
      moreVertBtn.dispatchEvent(new MouseEvent('mouseover',  bOpts));
      await delay(200);
      moreVertBtn.dispatchEvent(new PointerEvent('pointerdown', bOpts));
      moreVertBtn.dispatchEvent(new PointerEvent('pointerup',   bOpts));
      moreVertBtn.dispatchEvent(new MouseEvent('click', bOpts));
      await delay(600);

      const menuItemsNow = document.querySelectorAll('[role="menuitem"]').length;
      console.log(`[Flow] Tentativa ${attempt}: menu com ${menuItemsNow} itens`);

      // Menu pequeno (Renomear/Excluir) significa que clicou no lugar errado
      if (menuItemsNow < 9) {
        console.warn(`[Flow] Menu errado (${menuItemsNow} itens) — tentando novamente...`);
        document.body.click();
        await delay(500);
        continue;
      }

      const baixarBtn = await waitForElement(() => {
        for (const el of document.querySelectorAll('[role="menuitem"]')) {
          const txt = el.textContent?.trim() || '';
          if ((txt.includes('Baixar') || txt.includes('Download')) &&
              el.getAttribute('aria-disabled') !== 'true') return el;
        }
        return null;
      }, 8, 300);

      if (!baixarBtn) {
        console.warn(`[Flow] Tentativa ${attempt}: Menu Baixar não encontrado`);
        baixarNotFoundCount++;
        document.body.click();
        if (baixarNotFoundCount >= MAX_BAIXAR_FAILS) {
          console.warn('[Flow] Desistindo após 2 falhas de Baixar não encontrado');
          return false;
        }
        await delay(500);
        continue;
      }

      const bRect = baixarBtn.getBoundingClientRect();
      const bClick = {
        bubbles: true, cancelable: true,
        clientX: bRect.left + bRect.width  / 2,
        clientY: bRect.top  + bRect.height / 2,
      };
      baixarBtn.dispatchEvent(new MouseEvent('mouseenter', bClick));
      await delay(100);
      baixarBtn.dispatchEvent(new MouseEvent('click', bClick));
      await delay(800);

      // Aguarda o menu expandir com as opções de resolução antes de clicar em 720p
      const btn720 = await waitForElement(() => {
        if (document.querySelectorAll('[role="menuitem"]').length < 13) return null;
        return find720pButton();
      }, 20, 200);

      if (!btn720) {
        console.warn(`[Flow] Tentativa ${attempt}: 720p não encontrado — tentando novamente`);
        document.body.click();
        await delay(500);
        continue;
      }

      const rRect = btn720.getBoundingClientRect();
      const rOpts = {
        bubbles: true, cancelable: true,
        clientX: rRect.left + rRect.width  / 2,
        clientY: rRect.top  + rRect.height / 2,
      };

      setNextDownloadName(filename);
      await delay(100);
      btn720.dispatchEvent(new MouseEvent('mouseenter', rOpts));
      await delay(80);
      btn720.dispatchEvent(new MouseEvent('click', rOpts));

      console.log(`[Flow] ✅ 720p clicado — ${filename} (tentativa ${attempt})`);
      await delay(2500);
      return true;

    } catch(e) {
      console.error(`[Flow] Erro tentativa ${attempt}:`, e.message);
      document.body.click();
      await delay(500);
    }
  }

  console.warn(`[Flow] Desistindo após 8 tentativas — ${filename}`);
  return false;
}

// ─── Encontra botão 720p no menu aberto ──────────────────────────────────────
function find720pButton() {
  for (const item of document.querySelectorAll('[role="menuitem"]')) {
    if (item.getAttribute('aria-disabled') === 'true') continue;
    for (const child of item.querySelectorAll('*')) {
      if (child.children.length === 0 && child.textContent?.trim() === '720p') return item;
    }
    if (item.textContent?.trim().startsWith('720p')) return item;
  }
  return null;
}

// ─── ENVIA PROMPT ─────────────────────────────────────────────────────────────
async function sendPrompt(prompt) {
  try {
    const editor = await waitForElement(() => {
      const all = document.querySelectorAll('[data-slate-editor="true"]');
      for (const el of all) {
        if (el.getBoundingClientRect().top > window.innerHeight * 0.5) return el;
      }
      return all[0] || null;
    }, 20, 400);

    if (!editor) return false;

    editor.click(); await delay(300);
    editor.focus(); await delay(200);
    document.execCommand('selectAll', false, null);
    document.execCommand('delete',    false, null);
    await delay(150);

    const sel   = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(editor);
    range.collapse(false);
    sel.removeAllRanges();
    sel.addRange(range);

    editor.dispatchEvent(new InputEvent('beforeinput', {
      inputType: 'insertText', data: prompt, bubbles: true, cancelable: true,
    }));
    document.execCommand('insertText', false, prompt);
    editor.dispatchEvent(new Event('input', { bubbles: true }));
    await delay(500);

    if (editor.textContent.trim().length < 5) return false;

    const btn = await waitForElement(() => {
      const b = document.querySelector('button.bMhrec');
      if (b && !b.disabled) return b;
      return Array.from(document.querySelectorAll('button')).find(b =>
        b.querySelector('i')?.textContent.trim() === 'arrow_forward' && !b.disabled
      ) || null;
    }, 20, 400);

    if (!btn) return false;
    btn.click();
    await delay(800);
    return true;
  } catch(e) {
    return false;
  }
}
